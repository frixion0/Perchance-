export default async function handler(req, res) {
  const { prompt } = req.query;

  if (!prompt) {
    return res.status(400).json({ error: "Missing prompt" });
  }

  try {
    const apiUrl = `https://perchance.org/api/textToImage?prompt=${encodeURIComponent(prompt)}`;

    const response = await fetch(apiUrl);
    if (!response.ok) throw new Error("Perchance API error");

    const data = await response.json();

    res.status(200).json(data);
  } catch (err) {
    console.error("API Error:", err);
    res.status(500).json({ error: "Server error fetching from Perchance" });
  }
}
